package com.example.splashscreen;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
Button login,btn2;
TextView alreadyacc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportActionBar().hide();

        login = findViewById(R.id.btnlogin);
        btn2 = findViewById(R.id.btn2);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Login has been clicked", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MainActivity.this, SigninActivity.class);
                startActivity(intent);
                btn2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Toast.makeText(MainActivity.this, "you clicked on register", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(MainActivity.this, SignUp_Activity.class);
                        startActivity(intent);

                        alreadyacc = findViewById(R.id.textbottom);
                        alreadyacc.setOnClickListener(new View.OnClickListener() {

                            @Override
                            public void onClick(View v) {
                                Toast.makeText(MainActivity.this, "recently you clicked", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(MainActivity.this, SignUp_Activity.class);
                            }
                        });

                    }
                });
            }

        });
    }}